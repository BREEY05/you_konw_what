% c43wen.m - 非线性系统验证程序
% 系统: y(n) = x(n)*x(n-1)

clear all;
close all;
clc;

%% 参数设置
N = 20;         % 信号长度
n = 0:N-1;      % 时间序列
a = 2;          % 测试系数1
b = -3;         % 测试系数2

%% 系统定义
sys_response = @(x) [0, x(2:end).*x(1:end-1)];  % 正确使用圆括号进行函数定义

%% 1. 单位脉冲响应
x1 = [1 zeros(1,N-1)];      % 单位脉冲信号
y1 = sys_response(x1);      % 系统响应

%% 2. 阶跃响应
x2 = ones(1,N);             % 单位阶跃信号
y2 = sys_response(x2);      % 系统响应

%% 3. 正弦信号响应
x3 = sin(2*pi*n/10);        % 正弦信号
y3 = sys_response(x3);      % 系统响应

%% 4. 线性组合测试
x_comb = a*x1 + b*x2;       % 线性组合信号
y_direct = sys_response(x_comb);  % 直接处理组合信号
y_comb = a*y1 + b*y2;       % 分别处理后组合

%% 绘图展示
figure('Name','非线性系统验证','NumberTitle','off');

% 图1: 单位脉冲响应
subplot(2,2,1);
stem(n, y1, 'filled', 'LineWidth', 1.5);
title('(a) 单位脉冲响应');
xlabel('n'); ylabel('y(n)'); grid on;

% 图2: 阶跃响应
subplot(2,2,2);
stem(n, y2, 'filled', 'LineWidth', 1.5, 'Color', [0.85 0.325 0.098]);
title('(b) 阶跃响应');
xlabel('n'); ylabel('y(n)'); grid on;

% 图3: 正弦信号响应
subplot(2,2,3);
stem(n, y3, 'filled', 'LineWidth', 1.5, 'Color', [0.466 0.674 0.188]);
title('(c) 正弦信号响应');
xlabel('n'); ylabel('y(n)'); grid on;

% 图4: 线性组合测试
subplot(2,2,4);
stem(n, y_direct, 'filled', 'LineWidth', 1.5); hold on;
stem(n, y_comb, '--', 'LineWidth', 1.5, 'Color', [0.494 0.184 0.556]);
title('(d) 线性组合测试');
xlabel('n'); ylabel('幅值');
legend('直接处理', '分别组合', 'Location', 'northeast'); grid on;

%% 保存图形
saveas(gcf, 'nonlinear_system_verification.png');