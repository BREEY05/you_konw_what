#include "led.h"

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // ??? GPIOB ???
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    // ?? PB2 ?????
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;           // ?? PB2
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;    // ????
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;   // ?? 50MHz
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // PB2 ?????(???? LED)
    GPIO_SetBits(GPIOB, GPIO_Pin_2);
}