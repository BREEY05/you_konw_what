#include "stm32f10x.h"
#include "stdio.h"

// ??????
void delay_simple(volatile unsigned int count)
{
    while(count--);
}

// ??? printf ? USART1(??? MicroLIB)


int main(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;

    // 1. ?? GPIOA?GPIOB?USART1 ??
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_USART1, ENABLE);

    // 2. ?? PA9 ???????(USART1_TX)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 3. ?? PA10 ?????(USART1_RX)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 4. ?? PB2 ?????(LED)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // 5. ??? USART1(??? 115200,8?,???,1???)
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    // 6. ?? USART1
    USART_Cmd(USART1, ENABLE);

    // 7. ???
    while(1)
    {
        printf("Hello STM32\r\n");      // ? printf ??

        // LED ??
        GPIO_ResetBits(GPIOB, GPIO_Pin_2);
        delay_simple(500000);
        GPIO_SetBits(GPIOB, GPIO_Pin_2);
        delay_simple(500000);
    }
}