#include "stm32f10x.h"
#include "timer.h"

void TIM3_Int_Init(uint16_t arr, uint16_t psc)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Enable TIM3 clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    /* Configure TIM3 time base */
    TIM_TimeBaseStructure.TIM_Period = arr;
    TIM_TimeBaseStructure.TIM_Prescaler = psc;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    /* Clear update interrupt flag */
    TIM_ClearFlag(TIM3, TIM_FLAG_Update);

    /* Enable update interrupt */
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

    /* Configure TIM3 interrupt priority */
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

    NVIC_Init(&NVIC_InitStructure);

    /* Start TIM3 */
    TIM_Cmd(TIM3, ENABLE);
}

/* TIM3 interrupt handler */
void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);

        /* Toggle PB5 */
        if (GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_5) == Bit_SET)
        {
            GPIO_ResetBits(GPIOB, GPIO_Pin_5);
        }
        else
        {
            GPIO_SetBits(GPIOB, GPIO_Pin_5);
        }

        /* Toggle PB6 */
        if (GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_6) == Bit_SET)
        {
            GPIO_ResetBits(GPIOB, GPIO_Pin_6);
        }
        else
        {
            GPIO_SetBits(GPIOB, GPIO_Pin_6);
        }
    }
}