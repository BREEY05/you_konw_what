#include "stm32f10x.h"
#include "led.h"
#include "timer.h"

int main(void)
{
    /* ??? LED */
    LED_Init();

    /* ????????? */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    /*
     * ?? TIM3 ??? 72 MHz:
     * ?????:7199 + 1 = 7200
     * ????:72 MHz / 7200 = 10000 Hz
     * ????:4999 + 1 = 5000
     * ????:5000 / 10000 = 0.5 ?
     */
    TIM3_Int_Init(4999, 7199);

    while (1)
    {
        /* LED ??? TIM3 ???? */
    }
}