#ifndef __DELAY_H
#define __DELAY_H

void delay_init(void);
void delay_ms(unsigned int ms);

#endif