#include "exti.h"
#include "led.h"
#include "key.h"
#include "delay.h"
#include "usart.h"
#include "beep.h"

void EXTIX_Init(void)
{
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    KEY_Init();

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

    // KEY0 -> PB7,?????,?? EXTI_Line7
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource7);
    EXTI_InitStructure.EXTI_Line = EXTI_Line7;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    // KEY1 -> PB8,?????,?? EXTI_Line8
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource8);
    EXTI_InitStructure.EXTI_Line = EXTI_Line8;
    EXTI_Init(&EXTI_InitStructure);

    // WK_UP -> PA0,?????,?? EXTI_Line0
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_Init(&EXTI_InitStructure);

    // NVIC: EXTI0 (WK_UP)
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x03;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    // NVIC: EXTI9_5 (KEY0 ? EXTI7 ? KEY1 ? EXTI8 ????????)
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// WK_UP ??????
void EXTI0_IRQHandler(void)
{
    delay_ms(10);
    if (WK_UP == 1)
    {
        BEEP = !BEEP;
    }
    EXTI_ClearITPendingBit(EXTI_Line0);
}

// KEY0(EXTI7) ? KEY1(EXTI8) ????????
void EXTI9_5_IRQHandler(void)
{
    delay_ms(10);

    if (EXTI_GetITStatus(EXTI_Line7) != RESET)
    {
        if (KEY0 == 0)
        {
            LED0 = !LED0;
            LED1 = !LED1;
        }
        EXTI_ClearITPendingBit(EXTI_Line7);
    }

    if (EXTI_GetITStatus(EXTI_Line8) != RESET)
    {
        if (KEY1 == 0)
        {
            LED1 = !LED1;
        }
        EXTI_ClearITPendingBit(EXTI_Line8);
    }
}