clc
clear all 
close all
%%%定义参数
A=11;%%%学号
T=2;
tao=1;
dt=0.001;
omega=2*pi/T;
t=-T/2:dt:T/2;
%%%原始信号
f=zeros(length(t));
f((-tao/2-(-T/2))/dt:(tao/2-(-T/2))/dt)=A;
%%%定义合成信号波
F0=A*tao/T;
fN1=F0*ones(1,length(t));
fN2=F0*ones(1,length(t));
fN3=F0*ones(1,length(t));
N1=1;%%%一次谐波的和
for n = 1:2:N1
    fN1=fN1+2*A*tao/T*sinc(n*omega*tao/pi/2)*cos(n*omega*t);
end
N2=7;%%%前7次谐波的和
for n=1:2:N2
   fN2=fN2+2*A*tao/T*sinc(n*omega*tao/pi/2)*cos(n*omega*t);
end
N3=31;%%%前31次谐波的和
for n=1:2:N3
   fN3=fN3+2*A*tao/T*sinc(n*omega*tao/pi/2)*cos(n*omega*t);
end
figure;
subplot(3,1,1)
plot(t,f,'-.',t,fN1,'-')
xlabel('t')
ylabel('f(t)')
title(['N = ',num2str(N1)])

subplot(3,1,2)
plot(t,f,'-.',t,fN2,'-')
xlabel('t')
ylabel('f(t)')
title(['N = ',num2str(N2)])

subplot(3,1,3)
plot(t,f,'-.',t,fN3,'-')
xlabel('t')
ylabel('f(t)')
title(['N = ',num2str(N3)])