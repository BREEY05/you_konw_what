set(0,'defaultAxesFontName', 'Monospaced')
clc
clear all
close all
%%%定义时间
ts=0;
te=5;
dt=0.001;
t=ts:dt:te;
sys = tf(1,[1,2,100]);%%%系统描述
A=13;%%%学号
f=A*cos(2*pi*t);
y=lsim(sys,f,t);
figure;
plot(t,y)
xlabel('Time(Sec)')
ylabel('y(t)')
title('连续时间系统的零状态响应-求微分方程')