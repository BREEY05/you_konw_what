clc
clear all
num = [1,7,0];
den = [1,6,8];
[r,p,k] = residue(num,den);
