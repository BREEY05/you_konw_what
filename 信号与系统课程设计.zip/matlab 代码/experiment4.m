set(0,'defaultAxesFontName', '宋体');
clc
clear all
% close all
%%% 信号抽样
%%% 定义原始信号(Sa信号)
tstart = -10;
tend = 10;
tinterval = 0.001;
t = tstart:tinterval:tend;
A = 13;
ft = A*sinc(t/pi);
fm = 1/2/pi; %%% 信号的最高频率
%%% 原始信号的频谱
Wmax = 2 * pi;
N = 4000;
k = -N : N;
W = k * Wmax / N;
Ft = ft*exp(-1i*t'*W)*tinterval;
Ft_r = abs(Ft);
%%% 定义抽样信号
%%% 临界采样
fs1 = 2*fm; %%% 采样频率
Ts1 = 1/fs1; %%% 采样时间间隔
ts1 = tstart : Ts1 : tend; %%% 采样时刻
fst1 = A*sinc(ts1/pi); %%% 采样信号
%%% 临界采样信号的频谱
Fst1 = fst1*exp(-1i*ts1'*W)*Ts1;
Fst1_r = abs(Fst1);
%%% 过采样
fs2 = 4*fm; %%% 采样频率
Ts2 = 1/fs2; %%% 采样时间间隔
ts2 = tstart : Ts2 : tend; %%% 采样时刻
fst2 = A*sinc(ts2/pi); %%% 采样信号
%%% 过采样信号的频谱
Fst2 = fst2*exp(-1i*ts2'*W)*Ts2;
Fst2_r = abs(Fst2);
%%% 欠采样
fs3 = 1.5*fm; %%% 采样频率
Ts3 = 1/fs3; %%% 采样时间间隔
ts3 = tstart : Ts3 : tend; %%% 采样时刻
fst3 = A*sinc(ts3/pi); %%% 采样信号
%%% 临界采样信号的频谱
Fst3 = fst3*exp(-1i*ts3'*W)*Ts3;
Fst3_r = abs(Fst3);

figure;
subplot(4,2,1)
plot(t,ft)
title('原始信号','Fontsize',10,'Fontweight','Bold')
xlabel('t')
ylabel('f(t)')
grid on

subplot(4,2,2)
plot(W,Ft_r)
title('原始信号的频谱','Fontsize',10,'Fontweight','Bold')
xlabel('\omega')
ylabel('F(\omega)')
grid on

subplot(4,2,3)
stem(ts1,fst1)
title('临界采样信号（fs = 2fm）','Fontsize',10,'Fontweight','Bold')
xlabel('t')
ylabel('fs(t)')
subplot(4,2,4)
plot(W,Fst1_r)
title('临界采样信号的频谱','Fontsize',10,'Fontweight','Bold')
xlabel('\omega')
ylabel('Fs(\omega)')

subplot(4,2,5)
stem(ts2,fst2)
title('过采样信号（fs = 4fm）','Fontsize',10,'Fontweight','Bold')
xlabel('t')
ylabel('fs(t)')
subplot(4,2,6)
plot(W,Fst2_r)
title('过采样信号的频谱','Fontsize',10,'Fontweight','Bold')
xlabel('\omega')
ylabel('Fs(\omega)')

subplot(4,2,7)
stem(ts3,fst3)
title('欠采样信号（fs = 1.8fm）','Fontsize',10,'Fontweight','Bold')
xlabel('t')
ylabel('fs(t)')
subplot(4,2,8)
plot(W,Fst3_r)
title('欠采样信号的频谱','Fontsize',10,'Fontweight','Bold')
xlabel('\omega')
ylabel('Fs(\omega)')

set(gcf,'Color','w')
