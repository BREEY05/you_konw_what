set(0,'defaultAxesFontName', 'Monospaced')
clc
clear all
close all
%%%定义时间
ts=0;
te=15;
dt=0.001;
t=ts:dt:te;
sys = tf(1,[1,2,100]);%%%系统描述
A=13;%%%学号
f=A*cos(2*pi*t);
h=impulse(sys,t);
%%%计算两个离散时间序列的卷积
y2=conv(f,h);
%%%连续时间信号的卷积积分
y2=y2*dt;
%%%确定卷积结果的时间起点和终点
t_start=t(1)+t(1);%%%计算卷积和y的非零样值的起点位置
t_end=length(f)+length(h)-2;%%%计算卷积和y的非零样值的宽度
t_zs=t_start:dt:(t_end*dt+t_start);%%%确定卷积和y非零样值的时间向量
figure;
plot(t_zs,y2)
xlabel('Time(Sec)')
ylabel('y(t)')
title('连续时间系统的零状态响应-卷积法')