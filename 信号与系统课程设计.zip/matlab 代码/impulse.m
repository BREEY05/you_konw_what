clc
clear all
close all
%%%定义时间
ts=0;
te=5;
dt=0.001;
t=ts:dt:te;
A = 13;%%%学号
sys = tf([A],[1,2,100]);%%%系统描述
y=impulse(sys,t);
figure;
plot(t,y)
xlabel('Time(Sec)')
ylabel('y(t)')
title('连续时间系统的单位冲激响应')