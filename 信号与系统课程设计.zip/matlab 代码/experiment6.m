set(0,'defaultAxesFontName', '宋体');
clc
clear all
close all

num = [13,0];
den = [1,6,11,6];
sys = tf(num,den);
%%%零极点图
poles=roots(den);
figure;
subplot(2,2,[1 2])
pzmap(sys);
%%% 单位冲激响应
t = 0:0.02:10;
h = impulse(num,den,t);
subplot(2,2,3)
plot(t,h)
xlabel('time(s)')
ylabel('h(t)')
title('Impluse Respone')
%%% 频率响应
[H,w] = freqs(num,den);
subplot(2,2,4)
plot(w,abs(H))
xlabel('w')
ylabel('abs(H)')
title('Magnitude Response')
