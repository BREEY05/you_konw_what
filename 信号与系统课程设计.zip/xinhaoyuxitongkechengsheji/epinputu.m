close all;clc;clear all;
syms t w
Xjw = fourier(exp(-t)*heaviside(t),w); %用符号函数求傅里叶变换
subplot(1,2,1);fplot(abs(Xjw),[-10,10]);title('e^{-t}u(t)的幅度谱')
subplot(1,2,2);fplot(angle(Xjw),[-10,10]);title('e^{-t}u(t)的相位谱')