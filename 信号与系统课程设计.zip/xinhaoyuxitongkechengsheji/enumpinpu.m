close all;clc;clear all
dt = 0.01;
t = 0:dt:20;
x = exp(-t);
w = -20:0.01:20;
[W,T] = meshgrid(w,t);
X = dt*x*exp(-1i*T.*W);
subplot(1,2,1);plot(w,abs(X));title('e^{-t}u(t)的幅度谱')
subplot(1,2,2);plot(w,angle(X));title('e^{-t}u(t)的相位谱')