% 清空工作区和关闭所有图形窗口
clear;
close all;

% 定义符号变量
syms t w

% 定义信号 e^(-t)u(t)，其中 u(t) 是单位阶跃函数
x_t = exp(-t) * heaviside(t);

% 计算傅里叶变换
X_w = fourier(x_t, t, w);

% 显示傅里叶变换表达式
disp('傅里叶变换结果:');
pretty(X_w)

% 定义频率范围用于绘图
w_range = linspace(-20, 20, 1000); % 可根据需要调整范围

% 计算实部和虚部
real_part = double(subs(real(X_w), w, w_range));
imag_part = double(subs(imag(X_w), w, w_range));

% 绘制频谱实部和虚部
figure;
subplot(2,1,1);
plot(w_range, real_part);
title('频谱实部');
xlabel('角频率 \omega');
ylabel('幅度');
grid on;

subplot(2,1,2);
plot(w_range, imag_part);
title('频谱虚部');
xlabel('角频率 \omega');
ylabel('幅度');
grid on;