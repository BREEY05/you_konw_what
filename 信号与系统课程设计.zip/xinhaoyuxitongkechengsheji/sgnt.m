% 清空工作区和关闭所有图形窗口
clear;
close all;

% 定义符号变量
syms t w

% 定义符号函数 sgn(t)
sgn_t = sign(t);

% 计算傅里叶变换
F_w = fourier(sgn_t, t, w);

% 显示傅里叶变换表达式
disp('傅里叶变换结果:');
pretty(F_w)

% 理论上，sgn(t) 的傅里叶变换是 2/(j*w)，其中 j 是虚数单位
% 我们可以简化显示为：
F_w_simplified = simplify(F_w);
disp('简化后的傅里叶变换结果:');
pretty(F_w_simplified)

% 定义频率范围用于绘图（避开w=0处的奇点）
w_range_neg = linspace(-5, -0.1, 50); % 负频率部分
w_range_pos = linspace(0.1, 5, 50); % 正频率部分
w_range_full = [w_range_neg fliplr(w_range_pos)]; % 合并正负频率

% 计算幅度谱、相位谱、实部和虚部
magnitude_spectrum = abs(double(subs(F_w_simplified, w, w_range_full)));
phase_spectrum = angle(double(subs(F_w_simplified, w, w_range_full)));
real_part = real(double(subs(F_w_simplified, w, w_range_full)));
imag_part = imag(double(subs(F_w_simplified, w, w_range_full)));

% 绘制幅度谱
figure;
subplot(2,2,1);
plot(w_range_full, magnitude_spectrum);
title('幅度谱');
xlabel('角频率 \omega');
ylabel('幅度');
grid on;

% 绘制相位谱
subplot(2,2,2);
plot(w_range_full, phase_spectrum);
title('相位谱');
xlabel('角频率 \omega');
ylabel('相位 (弧度)');
grid on;

% 绘制频谱实部
subplot(2,2,3);
plot(w_range_full, real_part);
title('频谱实部');
xlabel('角频率 \omega');
ylabel('幅度');
grid on;

% 绘制频谱虚部
subplot(2,2,4);
plot(w_range_full, imag_part);
title('频谱虚部');
xlabel('角频率 \omega');
ylabel('幅度');
grid on;