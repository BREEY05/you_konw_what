close all;clc;clear all
syms t w;
Xjw = fourier(sinc(t),w);

real_part = real(Xjw);
imaginary_part = imag(Xjw);

% 设置绘图范围
w_values = linspace(-10, 10, 1000); % 频率轴上的点分布

% 替代 sym 变量 w 为具体的数值向量 w_values 来获得实际数据用于绘图
real_data = double(subs(real_part, 'w', w_values));
imaginary_data = double(subs(imaginary_part, 'w', w_values));

subplot(2,2,1);fplot(abs(Xjw),[-5,5]);
xlabel('\omega');ylim([-0.1,1.5]);title('Sa(\pit)的幅度谱')
grid on;

subplot(2,2,2);fplot(angle(Xjw),[-5,5]);
xlabel('\omega');ylim([-1,1]);title('Sa(\pit)的相位谱')
grid on;

subplot(2, 2, 3);
plot(w_values, real_data, '-b');
xlabel('\omega');
ylim([-0.1,1.5]);
ylabel('Re\{F(\omega)\}');
title('Sa(\pit) 频谱的实部');
grid on;

subplot(2, 2, 4);
plot(w_values, imaginary_data, '-r');
xlabel('\omega');
ylim([-1,1]);
ylabel('Im\{F(\omega)\}');
title('Sa(\pit) 频谱的虚部');
grid on;