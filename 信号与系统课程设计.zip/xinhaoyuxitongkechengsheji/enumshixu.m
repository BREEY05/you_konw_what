% 定义时间向量
t = linspace(-2, 5, 1000); % 时间范围可以根据需要调整
dt = mean(diff(t)); % 时间间隔

% 定义信号 e^(-t)u(t)
x_t = exp(-t).*(t >= 0);

% 计算离散傅里叶变换，并使用fftshift来展示完整的频谱
Y = fftshift(fft(x_t));
f = (-length(Y)/2:length(Y)/2-1)*(1/(dt*length(Y))); % 频率向量

% 绘制频谱实部和虚部
figure;
subplot(2,1,1);
plot(f, real(Y));
title('频谱实部');
xlabel('频率 (Hz)');
ylabel('幅度');

subplot(2,1,2);
plot(f, imag(Y));
title('频谱虚部');
xlabel('频率 (Hz)');
ylabel('幅度');