% 定义采样参数
T = 10; % 时间范围[-T,T]
dt = 0.1; % 采样间隔
t = -T:dt:T; % 时间序列
N = length(t); % 采样点数

% 生成离散化的sgn(t)信号
x = sign(t); % sign函数在Matlab中可用于生成符号函数对应的离散值

% 计算离散傅里叶变换
X = fft(x); 

% 计算对应的频率序列
fs = 1/dt; % 采样频率
f = (-fs/2:fs/N:fs/2 - fs/N); % 频率范围，使得0频率在中间

% 计算幅度谱
amp_spectrum = abs(X);

% 计算相位谱，使用angle函数，它会处理好相位的取值范围
phase_spectrum = angle(X);

% 计算频谱实部
real_part = real(X);

% 计算频谱虚部
imag_part = imag(X);

% 绘制幅度谱
subplot(2,2,1);
plot(f,amp_spectrum);
title('sgn(t)的幅度谱');
%xlabel('频率(Hz)');
%ylabel('Amplitude');

% 绘制相位谱
subplot(2,2,2);
plot(f,phase_spectrum);
title('sgn(t)的相位谱');
%xlabel('频率 (Hz)');
%ylabel('相位');

% 绘制频谱实部
subplot(2,2,3);
plot(f,real_part);
title('sgn(t)频谱的实部');
%xlabel('频率 (Hz)');
%ylabel('实部');

% 绘制频谱虚部
subplot(2,2,4);
plot(f,imag_part);
title('sgn(t)频谱的虚部');
%xlabel('频率(Hz)');
%ylabel('虚部');

%sgtitle('Frequency Domain Characteristics of sgn(t)');