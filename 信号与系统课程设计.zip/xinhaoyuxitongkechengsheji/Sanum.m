% 清空工作区和关闭所有图形窗口
clear;
clc
close all;

% 定义时间向量（选择足够大的范围以捕捉信号特性）
t = linspace(-10, 10, 100); % 使用2的幂次可以优化FFT性能
dt = mean(diff(t)); % 时间间隔

% 定义 Sa(pi*t) 函数
sa_pi_t = sinc(t); % 注意：MATLAB 中 sinc(x) 默认是 sin(pi*x)/(pi*x)

% 计算离散傅里叶变换 (DFT)，并使用fftshift来展示完整的频谱
Y = fftshift(fft(sa_pi_t));
N = length(Y);
df = 1 / (N * dt); % 频率分辨率
f = (-N/2:N/2-1) * df; % 频率向量

% 计算幅度谱、相位谱、实部和虚部
magnitude_spectrum = abs(Y) / N; % 归一化幅度谱
phase_spectrum = angle(Y);
real_part = real(Y) / N; % 归一化实部
imag_part = imag(Y) / N; % 归一化虚部

% 创建子图布局
figure;

% 绘制幅度谱
subplot(2,2,1);
plot(f, magnitude_spectrum);
title('幅度谱');
xlabel('频率 f');
ylabel('幅度');
grid on;

% 绘制相位谱
subplot(2,2,2);
plot(f, phase_spectrum);
title('相位谱');
xlabel('频率 f');
ylabel('相位 (弧度)');
grid on;

% 绘制频谱实部
subplot(2,2,3);
plot(f, real_part);
title('频谱实部');
xlabel('频率 f');
ylabel('幅度');
grid on;

% 绘制频谱虚部
subplot(2,2,4);
plot(f, imag_part);
title('频谱虚部');
xlabel('频率 f');
ylabel('幅度');
grid on;