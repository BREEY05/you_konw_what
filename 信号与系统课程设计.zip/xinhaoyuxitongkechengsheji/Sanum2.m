% 清空工作区和关闭所有图形窗口
clear;
clc;
close all;

% 定义符号变量
syms t w

T = 10; % 时间范围[-T,T]
dt = 0.5; % 采样间隔
t = -T:dt:T; % 时间序列
N = length(t); % 采样点数

% 定义符号函数 sgn(t)
Sa_t = sinc(t);
% 计算傅里叶变换
F_w = fftshift(fft(Sa_t));
% 定义采样参数

df = 1 / (N * dt); % 频率分辨率
f = (-N/2:N/2-1) * df; % 频率向量

% 计算幅度谱、相位谱、实部和虚部
magnitude_spectrum = abs(F_w);
phase_spectrum = angle(F_w);
real_part = real(F_w);
imag_part = imag(F_w);

% 绘制幅度谱
figure;
subplot(2,2,1);
plot(f, magnitude_spectrum);
title('幅度谱');
xlabel('频率 f(Hz)');
ylabel('幅度');
grid on;

% 绘制相位谱
subplot(2,2,2);
plot(f, phase_spectrum);
title('相位谱');
xlabel('频率 f(Hz)');
ylabel('相位 (弧度)');
grid on;

% 绘制频谱实部
subplot(2,2,3);
plot(f, real_part);
title('频谱实部');
xlabel('频率 f(Hz)');
ylabel('幅度');
grid on;

% 绘制频谱虚部
subplot(2,2,4);
plot(f, imag_part);
title('频谱虚部');
xlabel('频率 f(Hz)');
ylabel('幅度');
grid on;


