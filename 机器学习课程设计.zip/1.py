import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.svm import SVC
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from sklearn.metrics import precision_recall_curve, auc
import pandas as pd
import seaborn as sns
plt.rc('font',family='SimHei')


# 后端设置
matplotlib.use('TkAgg')  # 指定使用Tkinter作为后端

def plot_decision_boundary(clf, X, y, title, ax=None):
    """绘制SVM决策边界和支持向量"""
    if ax is None:
        ax = plt.gca()
    
    # 绘制决策边界
    x_min, x_max = X[:, 0].min() - 0.5, X[:, 0].max() + 0.5
    y_min, y_max = X[:, 1].min() - 0.5, X[:, 1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 500),
                         np.linspace(y_min, y_max, 500))
    
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    ax.contourf(xx, yy, Z, alpha=0.2, cmap=plt.cm.coolwarm)
    
    # 绘制数据点
    ax.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.coolwarm, edgecolors='k')
    
    # 绘制支持向量
    if hasattr(clf, 'support_vectors_'):
        ax.scatter(clf.support_vectors_[:, 0], clf.support_vectors_[:, 1], 
                   s=100, facecolors='none', edgecolors='k', alpha=0.5)
    
    ax.set_title(title)
    ax.set_xlabel('特征1')
    ax.set_ylabel('特征2')

def iris_experiment():
    """鸢尾花二分类实验"""

    # 数据准备
    iris = datasets.load_iris()
    X = iris.data[:, [1, 2]]  # 选择萼片宽度和花瓣长度
    y = iris.target
    X = X[y != 2]  # 只保留Setosa和Versicolor
    y = y[y != 2]
    
    # 实验1：硬间隔SVM（单独一张图）
    plt.figure(figsize=(8, 6))
    clf_hard = SVC(kernel='linear', C=1.0)
    clf_hard.fit(X, y)
    plot_decision_boundary(clf_hard, X, y, "硬间隔 SVM (C=1.0)")
    plt.tight_layout()
    plt.show()
    
    # 实验2：软间隔对比（一行三列）
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    for i, (C, ax) in enumerate(zip([0.01, 1, 100], axes)):
        clf = SVC(kernel='linear', C=C)
        clf.fit(X, y)
        plot_decision_boundary(clf, X, y, f"软间隔 SVM (C={C})", ax=ax)
        print(f"C={C}: 支持向量数量={len(clf.support_vectors_)}")
    plt.tight_layout()
    plt.show()
    
    # 实验3：非线性SVM
    X_moons, y_moons = make_moons(n_samples=100, noise=0.15, random_state=42)
    
    # 多项式核（三行三列）
    degrees = [2, 3, 5]
    coef0s = [0, 1, 2]
    fig, axes = plt.subplots(len(degrees), len(coef0s), figsize=(15, 12))
    for row, degree in enumerate(degrees):
        for col, coef0 in enumerate(coef0s):
            ax = axes[row, col]
            clf = SVC(kernel='poly', degree=degree, gamma='auto', coef0=coef0)
            clf.fit(X_moons, y_moons)
            plot_decision_boundary(clf, X_moons, y_moons, 
                                 f"多项式核 (d={degree}, r={coef0})", ax=ax)
    plt.tight_layout()
    plt.show()
    
    # 高斯核（一行三列）
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    for i, (gamma, ax) in enumerate(zip([0.1, 1, 10], axes)):
        clf = SVC(kernel='rbf', gamma=gamma)
        clf.fit(X_moons, y_moons)
        plot_decision_boundary(clf, X_moons, y_moons, f"高斯核 (gamma={gamma})", ax=ax)
    plt.tight_layout()
    plt.show()

# 执行实验
iris_experiment()