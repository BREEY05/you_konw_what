import numpy as np
from itertools import product

def generate_codewords(G):
    k = G.shape[0]
    codewords = []
    for u_tuple in product([0,1], repeat=k):
        u = np.array(u_tuple)
        c = (u @ G) % 2
        codewords.append((u.tolist(), c.tolist()))
    return codewords

G1 = np.array([[1, 0, 1, 1, 1],
               [0, 1, 1, 0, 1]])

print("【第一问】函数封装版：")
for u, c in generate_codewords(G1):
    print(f"{u} → {c}")