import numpy as np

# 设计一个最小码距为 3 的 (7, 3) 线性分组码的生成矩阵 G
# 例如，标准的 (7, 4) 汉明码的生成矩阵可以修改为 (7, 3) 码
G = np.array([[1, 0, 0, 1, 1, 0, 1],
               [0, 1, 0, 1, 0, 1, 1],
               [0, 0, 1, 0, 1, 1, 1]])

# 所有可能的信息位（2^3 = 8种组合）
info_bits = np.array([[0, 0, 0],
                      [0, 0, 1],
                      [0, 1, 0],
                      [0, 1, 1],
                      [1, 0, 0],
                      [1, 0, 1],
                      [1, 1, 0],
                      [1, 1, 1]])

# 编码过程
codewords = []
for info in info_bits:
    codeword = np.mod(np.dot(info, G), 2)
    codewords.append(codeword)

# 输出全部码字
codewords = np.array(codewords)
print("全部码字为：\n", codewords)

# 求校验矩阵 H
k, n = G.shape
P = G[:, k:]  # 提取生成矩阵的校验部分
I = np.eye(n - k, dtype=int)  # (n-k) x (n-k) 的单位矩阵
H = np.hstack((P.T, I))  # 校验矩阵 H

print("校验矩阵 H 为：\n", H)