import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
def shannon_capacity(B, SNR_linear):
    """
    计算香农信道容量
    B: 带宽 (Hz)
    SNR_linear: 线性信噪比 (S/N)
    返回: 信道容量 (bps)
    """
    return B * np.log2(1 + SNR_linear)

def plot_capacity_vs_bandwidth_snr():
    """
    绘制信道容量与带宽和信噪比的关系图
    """
    # 创建数据
    bandwidths = np.linspace(1e3, 10e3, 100)  # 带宽从1kHz到10kHz
    snr_db_values = np.linspace(0, 30, 6)     # 信噪比从0dB到30dB
    snr_linear_values = 10**(snr_db_values / 10)  # 转换为线性值
    
    plt.figure(figsize=(12, 5))
    
    # 子图1: 固定信噪比，容量vs带宽
    plt.subplot(1, 2, 1)
    for snr_db, snr_linear in zip(snr_db_values, snr_linear_values):
        capacities = shannon_capacity(bandwidths, snr_linear)
        plt.plot(bandwidths/1e3, capacities/1e3, 
                label=f'SNR={snr_db} dB', linewidth=2)
    
    plt.xlabel('带宽 (kHz)')
    plt.ylabel('信道容量 (kbps)')
    plt.title('固定信噪比下容量与带宽的关系')
    plt.grid(True, alpha=0.3)
    plt.legend()
    
    # 子图2: 固定带宽，容量vs信噪比
    plt.subplot(1, 2, 2)
    fixed_bandwidth = 5e3  # 固定带宽5kHz
    snr_db_range = np.linspace(-10, 40, 100)
    snr_linear_range = 10**(snr_db_range / 10)
    
    capacities = shannon_capacity(fixed_bandwidth, snr_linear_range)
    plt.plot(snr_db_range, capacities/1e3, 'r-', linewidth=2)
    
    plt.xlabel('信噪比 (dB)')
    plt.ylabel('信道容量 (kbps)')
    plt.title(f'固定带宽 ({fixed_bandwidth/1e3} kHz) 下容量与信噪比的关系')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()

def plot_3d_relationship():
    """
    绘制三维关系图
    """
    # 创建网格数据
    B = np.linspace(1e3, 10e3, 50)  # 带宽
    SNR_dB = np.linspace(0, 30, 50) # 信噪比(dB)
    B_grid, SNR_dB_grid = np.meshgrid(B, SNR_dB)
    
    # 计算信道容量
    SNR_linear_grid = 10**(SNR_dB_grid / 10)
    C_grid = shannon_capacity(B_grid, SNR_linear_grid)
    
    # 创建3D图形
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # 绘制曲面
    surf = ax.plot_surface(B_grid/1e3, SNR_dB_grid, C_grid/1e3, 
                          cmap='viridis', alpha=0.8)
    
    ax.set_xlabel('带宽 (kHz)')
    ax.set_ylabel('信噪比 (dB)')
    ax.set_zlabel('信道容量 (kbps)')
    ax.set_title('信道容量与带宽和信噪比的三维关系')
    
    # 添加颜色条
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5, label='容量 (kbps)')
    
    plt.show()

def interactive_calculator():
    """
    交互式计算器：根据输入的带宽和信噪比计算信道容量
    """
    print("\n" + "="*50)
    print("香农信道容量计算器")
    print("="*50)
    
    try:
        # 用户输入
        B = float(input("请输入带宽 (Hz): "))
        SNR_dB = float(input("请输入信噪比 (dB): "))
        
        # 计算
        SNR_linear = 10**(SNR_dB / 10)
        C = shannon_capacity(B, SNR_linear)
        
        # 输出结果
        print(f"\n计算结果:")
        print(f"- 带宽: {B} Hz")
        print(f"- 信噪比: {SNR_dB} dB (线性值: {SNR_linear:.4f})")
        print(f"- 信道容量: {C:.2f} bps")
        print(f"          = {C/1e3:.2f} kbps")
        print(f"          = {C/1e6:.4f} Mbps")
        
        # 计算频谱效率
        spectral_efficiency = C / B
        print(f"- 频谱效率: {spectral_efficiency:.4f} bps/Hz")
        
    except ValueError:
        print("错误: 请输入有效的数字!")
    except Exception as e:
        print(f"发生错误: {e}")

# 在主函数中调用这些可视化函数
if __name__ == "__main__":
    # 运行交互式计算器
    interactive_calculator()
    
    # 绘制二维关系图
    print("\n正在生成关系图...")
    plot_capacity_vs_bandwidth_snr()
    
    # 绘制三维关系图
    print("正在生成三维关系图...")
    plot_3d_relationship()
    
    # 示例计算
    print("\n" + "="*50)
    print("典型场景示例:")
    print("="*50)
    
    # 示例1: 电话信道
    B_phone = 3100  # 3.1kHz
    SNR_phone_dB = 30  # 30dB
    C_phone = shannon_capacity(B_phone, 10**(SNR_phone_dB/10))
    print(f"电话信道 (3.1kHz, 30dB): {C_phone/1e3:.1f} kbps")
    
    # 示例2: Wi-Fi信道
    B_wifi = 20e6  # 20MHz
    SNR_wifi_dB = 25  # 25dB
    C_wifi = shannon_capacity(B_wifi, 10**(SNR_wifi_dB/10))
    print(f"Wi-Fi信道 (20MHz, 25dB): {C_wifi/1e6:.1f} Mbps")
    
    # 示例3: 5G毫米波
    B_5g = 100e6  # 100MHz
    SNR_5g_dB = 20  # 20dB
    C_5g = shannon_capacity(B_5g, 10**(SNR_5g_dB/10))
    print(f"5G毫米波 (100MHz, 20dB): {C_5g/1e6:.1f} Mbps")