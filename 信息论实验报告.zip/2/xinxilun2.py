import numpy as np
import sys

def dmc_capacity():
    # 输入信道转移矩阵
    print("请输入信道转移矩阵 P=")
    print("示例格式: [[0.98, 0.02], [0.05, 0.95]]")
    P_input = input()

    try:
        # 解析输入矩阵
        P = np.array(eval(P_input), dtype=float)
    except:
        print("错误: 矩阵格式无效!")
        return

    n, m = P.shape
    e = float(input("请输入迭代精度：e="))

    for i in range(n):
        if abs(np.sum(P[i, :]) - 1) > 1e-8:
            print("错误: 矩阵P有误，行向量的和不为1!")
            return

        for j in range(m):
            if P[i, j] < 0 or P[i, j] > 1:
                print("错误: 矩阵P有误，矩阵元素概率值错误!")
                return
    
    Pa = np.ones(n) / n  # 设置初始值为等概分布
    Paa = Pa.copy()      # 最佳概率分布
    count = 0            # 初始迭代次数为0
    print("\n开始迭代计算...")

    while True:
        # 输出概率分布
        Pb = Paa @ P
        s1 = np.zeros(n)
        for i in range(n):
            a_val = 0
            for j in range(m):
                if P[i, j] != 0:
                    # 避免log(0)的情况
                    if Pb[j] > 0:
                        a_val += P[i, j] * np.log(P[i, j] / Pb[j])
            s1[i] = np.exp(a_val)
        
        s2 = Paa @ s1
        C1 = np.log(s2)           # 计算C(n+1,n)
        C2 = np.log(np.max(s1))   # 计算C'(n+1,n)
        count += 1
        
        if abs(C1 - C2) < e:
            C = 1.433 * C1  # 将信道容量的单位变为bit (1.433 = 1/ln(2))
            break
        else:
            # 重新调整输入概率分布
            Paa = (Paa * s1) / s2
    print('\n' + '='*50)
    print("计算结果:")
    print('='*50)
    print("输入信道转移矩阵:")
    print("P =")
    print(P)
    
    print("\n初始等概输入概率分布:")
    print("Pa =", Pa)
    
    print("\n最佳输入概率分布:")
    print("Paa =", Paa)
    
    print(f"\n信道容量: C = {C:.6f} 比特")
    
    print("\n输出概率分布:")
    print("Pb =", Pb)
    
    print(f"\n迭代次数: {count}")
    
    return C, Paa, Pb, count

def 示例用法():
    """
    示例用法函数
    """
    print("示例1: 二进制对称信道 (BSC), 错误概率p=0.1")
    print("P = [[0.9, 0.1], [0.1, 0.9]]")
    
    print("\n示例2: 二进制删除信道 (BEC), 删除概率ε=0.2")
    print("P = [[0.8, 0.2, 0], [0, 0.2, 0.8]]")
    
    print("\n示例3: Z型信道")
    print("P = [[1, 0], [0.1, 0.9]]")

def 测试二进制对称信道():
    """
    测试函数：二进制对称信道
    """
    print("\n" + "="*60)
    print("测试二进制对称信道 (BSC), 错误概率p=0.1")
    print("="*60)
    
    # 二进制对称信道，错误概率p=0.1
    P = np.array([[0.9, 0.1],   # P(Y|X=0)
                  [0.1, 0.9]])  # P(Y|X=1)
    
    e = 1e-6  # 迭代精度
    
    n, m = P.shape
    
    # 初始化
    Pa = np.ones(n) / n
    Paa = Pa.copy()
    count = 0
    
    while True:
        Pb = Paa @ P
        s1 = np.zeros(n)
        
        for i in range(n):
            a_val = 0
            for j in range(m):
                if P[i, j] != 0 and Pb[j] > 0:
                    a_val += P[i, j] * np.log(P[i, j] / Pb[j])
            s1[i] = np.exp(a_val)
        
        s2 = Paa @ s1
        C1 = np.log(s2)
        C2 = np.log(np.max(s1))
        count += 1
        
        if abs(C1 - C2) < e:
            C = 1.433 * C1  # 转换为比特单位
            break
        else:
            Paa = (Paa * s1) / s2
    
    print("信道矩阵:")
    print(P)
    print(f"计算得到的信道容量: {C:.6f} 比特")
    print(f"BSC(0.1)的理论容量: {1 + 0.1*np.log2(0.1) + 0.9*np.log2(0.9):.6f} 比特")
    print(f"最优输入分布: {Paa}")
    print(f"迭代次数: {count}")

def 测试二进制删除信道():
    """
    测试函数：二进制删除信道
    """
    print("\n" + "="*60)
    print("测试二进制删除信道 (BEC), 删除概率ε=0.2")
    print("="*60)
    
    # 二进制删除信道，删除概率ε=0.2
    P = np.array([[0.8, 0.2, 0],   # P(Y|X=0)
                  [0, 0.2, 0.8]])  # P(Y|X=1)
    
    e = 1e-6  # 迭代精度
    
    n, m = P.shape
    
    # 初始化
    Pa = np.ones(n) / n
    Paa = Pa.copy()
    count = 0
    
    while True:
        Pb = Paa @ P
        s1 = np.zeros(n)
        
        for i in range(n):
            a_val = 0
            for j in range(m):
                if P[i, j] != 0 and Pb[j] > 0:
                    a_val += P[i, j] * np.log(P[i, j] / Pb[j])
            s1[i] = np.exp(a_val)
        
        s2 = Paa @ s1
        C1 = np.log(s2)
        C2 = np.log(np.max(s1))
        count += 1
        
        if abs(C1 - C2) < e:
            C = 1.433 * C1  # 转换为比特单位
            break
        else:
            Paa = (Paa * s1) / s2
    
    print("信道矩阵:")
    print(P)
    print(f"计算得到的信道容量: {C:.6f} 比特")
    print(f"BEC(0.2)的理论容量: {1 - 0.2:.6f} 比特")
    print(f"最优输入分布: {Paa}")
    print(f"迭代次数: {count}")

if __name__ == "__main__":
    print("任意DMC信道容量计算程序")
    print("="*50)
    
    # 显示示例
    示例用法()
    print("\n" + "-"*50)
    
    # 运行测试用例
    测试二进制对称信道()
    测试二进制删除信道()
    
    print("\n" + "-"*50)
    print("现在进入交互式计算模式...")
    
    # 运行交互式计算
    try:
        dmc_capacity()
    except KeyboardInterrupt:
        print("\n程序被用户终止。")
    except Exception as e:
        print(f"发生错误: {e}")