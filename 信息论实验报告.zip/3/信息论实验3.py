import math
def float_to_binary_fraction(f, length):
    binary = ''
    for _ in range(length):
        f *= 2
        if f >= 1:
            binary += '1'
            f -= 1
        else:
            binary += '0'
    return binary

def shannon_code(symbols, probs):
    # Step 0: 检查
    if abs(sum(probs) - 1.0) > 1e-9:
        raise ValueError("概率之和必须为1")

    F = []
    cum = 0.0
    for p in probs:
        F.append(cum)
        cum += p

    lengths = [math.ceil(-math.log2(p)) for p in probs]
    codewords = []
    for i in range(len(F)):
        code = float_to_binary_fraction(F[i], lengths[i])
        codewords.append(code)

    entropy = -sum(p * math.log2(p) for p in probs)
    avg_len = sum(p * l for p, l in zip(probs, lengths))
    efficiency = entropy / avg_len

    print(f"{'符号':<6} {'P(x)':<8} {'F(x)':<10} {'l_i':<4} {'码字'}")
    print("-" * 40)
    for i in range(len(symbols)):
        print(f"{symbols[i]:<6} {probs[i]:<8.2f} {F[i]:<10.5f} {lengths[i]:<4} {codewords[i]}")

    print(f"\n信息熵 H(X)   = {entropy:.4f} 比特/符号")
    print(f"平均码长 L̄     = {avg_len:.4f} 比特/符号")
    print(f"编码效率 η     = {efficiency:.2%}")

    return codewords

symbols = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7']
probs   = [0.20, 0.19, 0.18, 0.17, 0.15, 0.10, 0.01]

shannon_code(symbols, probs)